import java.util.Scanner;

public class Branches {
    Scanner Input = new Scanner(System.in);
    public String _address;
    private String _branchname, _headMaster;
    private Integer _numofstudents, _numoftutors;

    public Branches(){}

    public Branches(String address, String branchname, String headmaster, Integer numofstudents, Integer numoftutors){
        set_address(address);
        set_branchname(branchname);
        set_headMaster(headmaster);
        set_numofstudents(numofstudents);
        set_numoftutors(numoftutors);
    }

    public String get_address(){
        return  _address;
    }
    public String get_branchname(){
        return  _branchname;
    }
    public String get_headMaster(){

        return  _headMaster;
    }
    public Integer get_numofstudents(){
        return  _numofstudents;
    }
    public Integer get_numoftutors(){
        return  _numoftutors;
    }

    public void set_address(String address){
        this._address = address;
    }
    public void set_branchname(String branchname){
        this._branchname = branchname;
    }
    public void set_headMaster(String headMaster){
        this._headMaster = headMaster;
    }
    public void set_numofstudents(Integer numofstudents){
        this._numofstudents = numofstudents;
    }
    public void set_numoftutors(Integer numoftutors){
        this._numoftutors = numoftutors;
    }
}
