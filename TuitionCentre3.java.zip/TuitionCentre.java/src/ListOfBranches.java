public class ListOfBranches {
    public Branches branches[] = new Branches[10];
    private int currentsize = 0;

    public ListOfBranches(Branches[] centers, int currentSize){
        this.branches = centers;
        this.currentsize = currentSize;
    }
    public ListOfBranches(){}

    public int getCurrentsize(){
        return currentsize;
    }

    public void setCurrentsize(int currentsize){
        this.currentsize = currentsize;
    }

    public void add(Branches branches,int index){
        this.branches[index] = branches;
    }

    public void add(Branches branches){
        this.branches[currentsize++] = branches;
    }

    public boolean find(String centerName){
        boolean found = false;

        for (int i = 0; i <= currentsize; i++){
            if (branches[i].get_branchname() == centerName)
                found = true;
        }

        return found;
    }


}
