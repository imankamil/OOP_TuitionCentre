import javafx.util.Pair;

class MinMax {


    public static Pair<Double,Double> minmax(student first_student){
        double minimum=99999;
        double maximum = 0;

        if(first_student.get_BahasaMelayu()<minimum){
            minimum = first_student.get_BahasaMelayu();
        } else if (first_student.get_BahasaInggeris()<minimum){
            minimum = first_student.get_BahasaInggeris();
        } else if (first_student.get_Mathematics()<minimum){
            minimum = first_student.get_Mathematics();
        } else if (first_student.get_Science()<minimum){
            minimum = first_student.get_Science();
        }

        if(first_student.get_BahasaMelayu()>maximum){
            maximum = first_student.get_BahasaMelayu();
        } else if (first_student.get_BahasaInggeris()>maximum){
            maximum = first_student.get_BahasaInggeris();
        } else if (first_student.get_Mathematics()>maximum){
            maximum = first_student.get_Mathematics();
        } else if (first_student.get_Science()>maximum){
            maximum = first_student.get_Science();
        }

        return new Pair<Double,Double>(maximum,minimum);
    }
}
