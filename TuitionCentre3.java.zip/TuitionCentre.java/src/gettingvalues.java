import javafx.util.Pair;

public class gettingvalues {

    public static Pair<Integer,Integer> BmBi(student first_student){
        Integer BM = first_student.get_BahasaMelayu();
        Integer BI = first_student.get_BahasaInggeris();

        return new Pair<Integer,Integer>(BM,BI);
    }
}
