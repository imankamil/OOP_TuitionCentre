import javafx.util.Pair;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;


public class Main {
    public static void main(String[] args) {
        Scanner Input = new Scanner(System.in);

        Integer BM = 0,BI = 0,MT = 0,SC = 0;
        String tutorName = "", tutorIC = "", tutorAdd = "", tutorQualification = "", yearExp= "", dateJoined = "", yearsInCentre = "",studentName = "",studentIC = "",studentAddress = "",studentYear = "", schoolName = "";
        Integer BatuGajah = 0, DPP = 0, Semenyih = 0, batuPahat = 0;

        tutor first_tutor = new tutor(tutorName, tutorIC, tutorAdd, tutorQualification, yearExp, dateJoined, yearsInCentre);
        student first_student = new student(studentName,studentIC,studentAddress,studentYear,schoolName,BM,BI,MT,SC);

        System.out.println(first_tutor.toString_tutors());

        System.out.println(first_student.toString_students());

        Pair<Double,String> p = calculation.calc(first_student);
        System.out.println("Average is " + p.getKey() + "\n Performance: " + p.getValue());

        ListOfBranches batugajah = new ListOfBranches();

        Pair<Double,Double> q = MinMax.minmax(first_student);
        System.out.println("Maximum is " + q.getKey() + "\n Minimum is " + q.getValue());





    }
}